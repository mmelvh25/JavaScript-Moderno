# js-blackjack
Así dejamos el código en la sección 6
