







let _objeto$123 = 123;
let precio99_99 = 123;

let jugadorConPuntajeMasAlto = 'Fernando';

class JuegoAnio {

}