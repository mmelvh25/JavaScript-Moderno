


alert('Hola Mundo');


let nombre = prompt('¿Cuál es tu nombre?');
console.log( nombre );
console.log( '****' + nombre + '****' ); // ''

const seleccion = confirm('¿Está seguro de borrar esto?');
console.log( seleccion );

// console.log( global );

